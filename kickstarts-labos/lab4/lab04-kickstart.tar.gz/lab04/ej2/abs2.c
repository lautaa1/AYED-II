#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

void absolute(int x, int *y) {
    //
    // Completar aquí
    //
}

int main(void) {
    int a=0, res=0;  // No modificar esta declaración
    // --- No se deben declarar variables nuevas ---

    //
    // Completar aquí
    //
    assert(res >= 0 && (res == a || res == -a));
    return EXIT_SUCCESS;
}

